let els = document.getElementsByClassName("abc")

for (let e of els) {
    e.style.color = "darkgrey"
}

document.getElementById("clickme").addEventListener("click", function() {
    let atask = (document.getElementById('barney').value)
    let tasks = (document.getElementById('tasklist'))

      let li = document.createElement('li');
      li.addEventListener('click', function() {
        li.remove();
      })
   li.appendChild(document.createTextNode(atask));
   tasks.appendChild(li);
// ADDS TO list


 // let rtask = (document.getElementById("li").addEventListener("click", function()) {
   //   li.parentNode.removeChild('li');
   // }
})


let p = document.getElementById('p1')
p.addEventListener("click", function() {
p.style.color = "green";
});

let q = document.getElementById('p2')
q.addEventListener("click", function() {
q.style.color = "blue";
});

let obj = {
  age: 99,
  getOlder: function() {
    this.age = this.age + 1;
  }
  }

  obj.getOlder()

  function add(x,y) {
    return x + y;
  }
console.log(add(5,7));
(function() {
    var widget, initAddressFinder = function() {
        widget = new AddressFinder.Widget(
            document.getElementById('addrs_1'),
            'ADDRESSFINDER_DEMO_KEY',
            'NZ', {
                "address_params": {}
            }
        );
        widget.on('result:select', function(fullAddress, metaData) {
            var selected = new AddressFinder.NZSelectedAddress(fullAddress, metaData);
            // TO DO - You will need to update these ids to match those in your form
            document.getElementById('addrs_1').value = selected.address_line_1();
            document.getElementById('addrs_2').value = selected.address_line_2();
            document.getElementById('suburb').value = selected.suburb();
            document.getElementById('city').value = selected.city();
            document.getElementById('postcode').value = selected.postcode();
        });
    };

    function downloadAddressFinder() {
        var script = document.createElement('script');
        script.src = 'https://api.addressfinder.io/assets/v3/widget.js';
        script.async = true;
        script.onload = initAddressFinder;
        document.body.appendChild(script);
    };

    document.addEventListener('DOMContentLoaded', downloadAddressFinder);
})();

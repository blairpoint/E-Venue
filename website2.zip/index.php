
<?php
$conn_string = "host=13.210.214.176 port=5432 dbname=test user=blairuser password=Fiddler56!";
$conn = pg_connect($conn_string);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Evenue</title>
		<!-- this is a comment -->
		<link rel="stylesheet" type="text/css" href="style.css" />
	</head>

	<body style="background: #bfffd0">
		<ul id="menu">
				<li>Events
				<ul>
					<li>Add Event</li>

				</ul>
			</li>
			<li>Venues
				<ul>
					<li><a href="venues.php">Add Venue</a></li>

				</ul>
			</li>
</ul>

<?php
		$result = pg_query($conn, "SELECT * FROM venues;");
		while ($row = pg_fetch_assoc($result) ){
			$img_pathumb = "uploads/".$row['thumbname'];
			$img_pathfp = "uploads/".$row['fpimagename'];
		echo   "<table id='roller'>
								<tr>
		            <td><img src=".$img_pathumb." height='100'></td>
		            <td>
								<ul>
									<li>Venue name: ".$row['venuename']."</li>
		              <li>Capacity: ".$row['capacity']."</li>
								<li>City: ".$row['city']."</li>
								<li>Address: ".$row['address']."</li>
								</ul>
								</td>
								<td><img src=".$img_pathfp." height='100'></td>
		        </tr>";
		}
		echo  "</table></body></html>";
?>

		<script type="text/javascript" src="fred.js" ></script>

	</body>
</html>

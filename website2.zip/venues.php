
<?php
$conn_string = "host=13.210.214.176 port=5432 dbname=test user=blairuser password=Fiddler56!";
$conn = pg_connect($conn_string);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Evenue</title>
		<!-- this is a comment -->
		<link rel="stylesheet" type="text/css" href="style.css" />
	</head>
	<body style="background: #bfffd0">
		<ul id="menu">
			<li><a href=index.php>Home</a></li>
			<li>Events
				<ul>
					<li>Add Event</li>

				</ul>
			</li>
			<li>Venues
				<ul>
					<li>Add Venue</li>

				</ul>
			</li>
</ul>
Add a new Venue<Br>

	<table>
		<tr>


	<td>
			<form action="upload.php" method="post" enctype="multipart/form-data">
		<label for="vname"> Venue name:</label><br>
	<input type="text" name="venuename"><br>
	<label for="thumb"> Thumbnail:</label><br>

	 	  <input type="file" name="thumbToUpload" id="thumbToUpload">
<br>
	<label for="cap"> Capacity:</label><br>
	<input type="text" name="capacity"><br>
	<label for="city"> City:</label><br>
<input type="text" name="cityname"><br>
<label for="addr"> Address:</label><br>
<input type="text" name="address"><br>
<label for="floorp"> Floorplan:</label><br>
<!-- <form action="upload.php" method="post" enctype="multipart/form-data"> -->
		<input type="file" name="fileToUpload"><br><br>
	<input type="submit" value="submit" name="submit">

</form><br>
</td>
</table>

	<!-- <button id="clickme"> Submit </button> -->
		<script type="text/javascript" src="fred.js" ></script>

	</body>
</html>
